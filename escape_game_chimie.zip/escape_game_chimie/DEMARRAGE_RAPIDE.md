# 🚀 DÉMARRAGE RAPIDE

## En 5 minutes, vous êtes prêt !

### 1️⃣ TESTER LE JEU (2 min)

1. Ouvrir le fichier `jeu/escape_game_ameliore.html` dans votre navigateur
2. Entrer un nom d'équipe test (ex: "Test Prof")
3. Choisir "Normal" comme difficulté
4. Cliquer sur "🚀 COMMENCER L'ENQUÊTE"

**✨ Vous pouvez maintenant explorer les énigmes !**

---

### 2️⃣ OUVRIR LE TABLEAU DE BORD (1 min)

1. Dans un nouvel onglet, ouvrir `enseignant/tableau_bord_enseignant.html`
2. Voir les statistiques s'afficher automatiquement
3. Tester l'export CSV

**📊 Vous pouvez suivre les résultats en temps réel !**

---

### 3️⃣ LIRE LA CORRECTION (2 min)

1. Ouvrir `ressources/fiche_correction_enseignant.html`
2. Parcourir les solutions des 5 énigmes
3. Noter les points d'attention pédagogiques

**✅ Vous avez toutes les réponses détaillées !**

---

## 📋 CHECKLIST PRE-SEANCE

Avant d'utiliser le jeu en classe :

### La veille
- [ ] Tester le jeu sur les ordinateurs de la salle
- [ ] Vérifier la connexion Internet (pour les images)
- [ ] Imprimer les fiches d'aide si nécessaire
- [ ] Préparer les équipes (liste des groupes)

### Le jour J
- [ ] Ouvrir le jeu sur chaque poste
- [ ] Ouvrir le tableau de bord sur votre ordinateur
- [ ] Préparer un chronomètre visible
- [ ] Avoir la fiche correction sous la main

---

## ⚡ DÉMARRAGE EXPRESS EN CLASSE

### Introduction (5 min)
```
"Aujourd'hui, escape game ! Un échantillon de cuivre a été volé.
Vous devez résoudre 5 énigmes pour identifier le coupable.
Vous avez 60 minutes. C'est parti !"
```

### Formation des équipes (3 min)
- 3-4 élèves par équipe
- Groupes hétérogènes
- Un coordinateur, un secrétaire, un chercheur, un vérificateur

### Lancement (2 min)
- Chaque équipe choisit un nom
- Choisit sa difficulté
- Clique sur "Commencer"

**🎮 Le jeu commence !**

---

## 🆘 AIDE RAPIDE

### Un élève bloque ?
➜ Ne pas donner la réponse, poser une question :
- "Qu'est-ce qu'un oxydant fait ?"
- "Regarde le coefficient, que remarques-tu ?"

### Une équipe a fini ?
➜ Proposer les énigmes bonus dans `ressources/variantes_enigmes.html`

### Problème technique ?
➜ La touche F5 recharge la page
➜ Les données sont sauvegardées automatiquement

---

## 📊 APRÈS LA SÉANCE

1. **Exporter les résultats** : Bouton "📥 EXPORTER CSV" dans le tableau de bord
2. **Correction collective** : 15 min avec la fiche correction
3. **Bilan** : Noter ce qui a bien/moins bien fonctionné

---

## 💡 ASTUCES PRO

### Pour plus d'engagement
🎯 Annoncer un petit prix pour l'équipe gagnante  
🎯 Afficher un classement en temps réel  
🎯 Mettre une musique d'ambiance discrète

### Pour faciliter
🎯 Autoriser l'accès au cours en mode "facile"  
🎯 Préparer des indices supplémentaires  
🎯 Donner des rappels de temps (30 min, 15 min, 5 min)

---

## 🎯 OBJECTIF MINIMUM

**Si vous n'avez le temps de lire qu'UN SEUL document :**
👉 Lisez le `README.md`

**Si vous avez 10 minutes de plus :**
👉 Parcourez le `guide_utilisation_pedagogique.html`

**Pour aller plus loin :**
👉 Explorez les `variantes_enigmes.html`

---

## 🎓 PREMIER USAGE : MODE DÉCOUVERTE

### Option sécurité (recommandée pour la 1ère fois)

1. **Séance 1** : Test avec une petite classe
2. **Observer** : Prendre des notes sur ce qui fonctionne
3. **Ajuster** : Modifier si nécessaire
4. **Séance 2+** : Utiliser en toute confiance

### Timing suggéré
- 10 min : Introduction et règles
- 50 min : Phase de jeu
- 15 min : Correction et bilan
- **Total : 75 minutes**

---

## ❓ QUESTIONS FRÉQUENTES

**Q : Ça fonctionne sans Internet ?**  
✅ Oui, sauf pour les images (portraits des suspects)

**Q : Sur tablettes aussi ?**  
✅ Oui, mais ordinateur recommandé pour le confort

**Q : Je peux modifier les énigmes ?**  
✅ Oui, les fichiers HTML sont éditables

**Q : C'est noté ?**  
➜ À vous de décider ! Recommandation : évaluation formative

---

## 📞 BESOIN D'AIDE ?

1. Relire le `README.md` (section FAQ)
2. Consulter le `guide_utilisation_pedagogique.html`
3. Tester avec un collègue avant la vraie séance
4. Contacter d'autres enseignants utilisateurs

---

## ✨ BON COURAGE ET AMUSEZ-VOUS !

**L'enseignement peut être ludique ET efficace !** 🎓🎮

---

**Prochaine étape recommandée :**  
👉 Ouvrir `README.md` pour une vue d'ensemble complète