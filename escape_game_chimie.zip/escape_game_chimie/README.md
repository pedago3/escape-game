# 🔬 Escape Game - Mystère au Laboratoire de Chimie

## 📖 Description

Un escape game pédagogique interactif pour l'enseignement de l'oxydoréduction et du bilan de matière en classe de Première.

**Thème :** Oxydoréduction et Bilan de Matière  
**Niveau :** Première  
**Durée :** 45-60 minutes  
**Format :** Équipes de 3-4 élèves

---

## 🎯 Objectifs Pédagogiques

### Connaissances
- Identifier un oxydant et un réducteur
- Reconnaître une oxydation et une réduction
- Écrire des demi-équations électroniques
- Établir une équation d'oxydoréduction
- Construire et utiliser un tableau d'avancement
- Déterminer le réactif limitant

### Compétences
- **S'approprier** : Analyser un problème
- **Analyser** : Mobiliser ses connaissances
- **Réaliser** : Appliquer une méthode
- **Valider** : Vérifier la cohérence
- **Communiquer** : Échanger en équipe

---

## 📁 Structure du Projet

```
escape_game_chimie/
│
├── jeu/
│   └── escape_game_ameliore.html          # Jeu principal (élèves)
│
├── enseignant/
│   └── tableau_bord_enseignant.html       # Suivi des résultats
│
├── ressources/
│   ├── fiche_correction_enseignant.html   # Correction détaillée
│   ├── guide_utilisation_pedagogique.html # Guide d'utilisation
│   └── variantes_enigmes.html             # Variantes pour éviter la triche
│
├── images/
│   └── (portraits des suspects + schémas)
│
└── README.md                               # Ce fichier
```

---

## 🚀 Installation et Utilisation

### Pour l'Enseignant

#### 1. Préparation
1. Télécharger tous les fichiers du projet
2. Ouvrir `jeu/escape_game_ameliore.html` dans un navigateur pour tester
3. Ouvrir `enseignant/tableau_bord_enseignant.html` dans un autre onglet
4. Lire le `guide_utilisation_pedagogique.html` pour la mise en place

#### 2. En Classe
1. **Avant la séance** : Vérifier que tous les ordinateurs fonctionnent
2. **Démarrage** (10 min) : 
   - Expliquer le scénario aux élèves
   - Former les équipes de 3-4
   - Distribuer les liens du jeu
3. **Pendant** (45-60 min) :
   - Circuler entre les équipes
   - Observer et guider sans révéler
   - Suivre les résultats sur le tableau de bord
4. **Après** (15 min) :
   - Correction collective
   - Synthèse des notions
   - Bilan pédagogique

### Pour les Élèves

1. Ouvrir le lien fourni par l'enseignant
2. Entrer le nom de l'équipe
3. Choisir un niveau de difficulté
4. Résoudre les 5 énigmes en équipe
5. Identifier le coupable !

---

## ✨ Fonctionnalités Principales

### ✅ Pour les Élèves

#### Système de Sauvegarde Automatique
- La progression est sauvegardée automatiquement toutes les 30 secondes
- Possibilité de reprendre une partie interrompue
- Données stockées localement (localStorage)

#### Trois Niveaux de Difficulté
- **Facile** : 90 minutes, plus d'indices
- **Normal** : 60 minutes, indices standard
- **Difficile** : 45 minutes, moins d'indices

#### Interface Accessible
- Design responsive (PC, tablettes, smartphones)
- Support du mode contraste élevé
- Navigation au clavier (Tab, Enter)
- Attributs ARIA pour lecteurs d'écran

#### Système d'Indices
- Indices progressifs par énigme
- Nombre limité selon la difficulté
- Compteur d'indices utilisés

#### Timer Dynamique
- Compte à rebours visible
- Alertes visuelles (temps critique)
- Pause automatique en cas d'inactivité

### ✅ Pour l'Enseignant

#### Tableau de Bord en Temps Réel
- Suivi de la progression de chaque équipe
- Statistiques globales de la classe
- Analyse par énigme
- Export des résultats en CSV

#### Indicateurs Pédagogiques
- Temps moyen par énigme
- Nombre d'indices utilisés
- Taux de réussite
- Identification des difficultés

#### Recommandations Personnalisées
- Analyse automatique des performances
- Suggestions d'approfondissement
- Points de vigilance par équipe

---

## 📊 Les 5 Énigmes

### Énigme 1 : La trace sur la porte
**Notion :** Oxydant, réducteur et transfert d'électrons  
**Code à trouver :** O-O-C

### Énigme 2 : Le coffre du laboratoire
**Notion :** Demi-équations électroniques  
**Code à trouver :** 1-2-1-3

### Énigme 3 : Le message dans le coffre
**Notion :** Équation d'oxydoréduction complète  
**Coefficient à trouver :** 2

### Énigme 4 : Le tableau mystérieux
**Notion :** Tableau d'avancement  
**Code à trouver :** 2

### Énigme 5 : Le réactif limitant révèle le coupable
**Notion :** Réactif limitant  
**Coupable :** Jules Limitant

---

## 🎲 Variantes Disponibles

Pour éviter la triche et renouveler l'activité, 3 variantes de chaque énigme sont disponibles dans `ressources/variantes_enigmes.html` :

- **Version A** : Énigmes originales
- **Version B** : Réactions différentes, codes différents
- **Version C** : Quantités modifiées, nouveaux calculs

**+ 5 énigmes bonus** pour les équipes rapides !

---

## 🔧 Personnalisation

### Modifier les Énigmes

Les fichiers HTML sont facilement modifiables :

1. Ouvrir le fichier dans un éditeur de texte
2. Localiser la section `<section id="enigme-X">`
3. Modifier les questions, valeurs, ou réponses
4. Ajuster la validation dans la section `<script>`

### Adapter la Difficulté

Dans `escape_game_ameliore.html`, modifier :

```javascript
const difficultySettings = {
    facile: {
        time: 5400,        // Temps en secondes
        hintsMultiplier: 1.5
    },
    // ...
};
```

### Changer les Visuels

Remplacer les images dans le dossier `images/` en conservant les mêmes noms de fichiers.

---

## 📈 Exploitation Pédagogique

### Avant le Jeu
- Rappel des notions clés (15 min)
- Formation des équipes hétérogènes
- Explication des règles

### Pendant le Jeu
- Circulation discrète de l'enseignant
- Observation des démarches
- Aide ciblée sans révéler les réponses

### Après le Jeu
- Correction collective (15 min)
- Verbalisation des difficultés
- Consolidation des notions
- Exercices complémentaires

---

## 💡 Astuces et Bonnes Pratiques

### Pour Maximiser l'Engagement
✅ Prévoir un petit prix symbolique pour l'équipe gagnante  
✅ Afficher un classement en temps réel  
✅ Créer une ambiance (musique discrète, lumières tamisées)  
✅ Valoriser la démarche, pas seulement le résultat

### Pour Éviter les Blocages
✅ Préparer des indices supplémentaires  
✅ Former des équipes équilibrées  
✅ Autoriser l'accès au cours en mode "facile"  
✅ Donner des rappels temporels réguliers

### Pour l'Évaluation
✅ Grille d'observation pendant le jeu  
✅ Auto-évaluation des élèves après  
✅ Contrôle individuel la séance suivante  
✅ Production d'énigmes par les élèves

---

## 🛠️ Technologies Utilisées

- **HTML5** : Structure du jeu
- **CSS3** : Design et animations
- **JavaScript** : Logique et interactivité
- **Tailwind CSS** : Framework CSS
- **LocalStorage** : Sauvegarde des données

**Aucune installation requise** - Fonctionne dans n'importe quel navigateur moderne.

---

## 📱 Compatibilité

### Navigateurs Supportés
✅ Chrome / Edge (recommandé)  
✅ Firefox  
✅ Safari  
✅ Opera

### Appareils
✅ Ordinateurs (Windows, Mac, Linux)  
✅ Tablettes (iPad, Android)  
✅ Smartphones (avec réserves pour le confort)

---

## 🎓 Liens avec le Programme

### Programme Officiel de Première
- **Thème** : Constitution et transformations de la matière
- **Sous-thème** : Modéliser l'évolution d'un système
- **Notions** : 
  - Oxydant, réducteur, couple redox
  - Écriture symbolique des réactions
  - Tableau d'avancement
  - Réactif limitant

### Compétences du Socle
- Pratiquer des démarches scientifiques
- Concevoir, créer, réaliser
- Coopérer et faire preuve de responsabilité
- Pratiquer des langages

---

## 📚 Ressources Complémentaires

### Documents Fournis
1. **Fiche de correction** : Solutions détaillées avec explications
2. **Guide pédagogique** : Conseils de mise en œuvre
3. **Variantes** : Énigmes alternatives
4. **Visuels** : Portraits des suspects + schémas chimiques

### Pour Aller Plus Loin
- Vidéos pédagogiques sur l'oxydoréduction
- TP expérimental : Réaliser la réaction Ag⁺/Cu
- Exercices interactifs en ligne
- Projets interdisciplinaires (SVT, Technologie)

---

## ❓ FAQ

**Q : Combien de temps prévoir pour l'activité complète ?**  
R : 75-90 minutes (introduction + jeu + débrief)

**Q : Peut-on jouer sans connexion Internet ?**  
R : Oui, une fois les fichiers téléchargés. Les images des suspects nécessitent Internet.

**Q : Comment récupérer les résultats des élèves ?**  
R : Via le tableau de bord enseignant (export CSV disponible)

**Q : Les données sont-elles partagées en ligne ?**  
R : Non, tout est stocké localement dans le navigateur (localStorage)

**Q : Puis-je utiliser ce jeu en évaluation ?**  
R : Oui, mais prévoir une évaluation individuelle complémentaire

---

## 📞 Support et Contact

Pour toute question, suggestion ou retour d'expérience :

- 📧 Contact enseignant : [Votre email]
- 🌐 Ressources supplémentaires : [Votre site]
- 💬 Communauté enseignants : [Forum/Réseau]

---

## 📄 Licence et Utilisation

Ce projet éducatif est mis à disposition pour l'enseignement.

**Vous êtes libre de :**
- ✅ Utiliser le jeu dans votre classe
- ✅ Modifier et adapter les contenus
- ✅ Partager avec vos collègues

**Merci de :**
- 📝 Citer la source si vous partagez
- 💬 Partager vos retours d'expérience
- 🌟 Contribuer avec vos améliorations

---

## 🙏 Remerciements

Merci aux enseignants de chimie qui ont inspiré ce projet et à tous ceux qui l'utiliseront pour rendre leurs cours plus vivants !

**Créé avec ❤️ pour l'enseignement des sciences**

---

## 🔄 Historique des Versions

### Version 2.0 (Novembre 2024)
✨ Ajout de la sauvegarde automatique  
✨ Tableau de bord enseignant  
✨ Trois niveaux de difficulté  
✨ Amélioration de l'accessibilité  
✨ Visuels des suspects  
✨ Guide pédagogique complet  
✨ Variantes d'énigmes

### Version 1.0 (Initiale)
🎮 Jeu de base avec 5 énigmes  
⏱️ Timer et système de points  
💡 Système d'indices

---

**Bon jeu et excellent enseignement ! 🎓🔬**